#!/bin/bash
# Run for each question
echo "========================"
echo "Experiments 1"
echo "========================"
python3.5 DecisionTree.py
echo "========================"
echo
echo

echo "========================"
echo "Experiments 2"
echo "========================"
python3.5 DecisionTreeDepth.py
echo "========================"
echo
echo