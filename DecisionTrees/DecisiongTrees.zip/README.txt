The code has been executed on CADE machine Lab1-20 using python3.5

This directory contains -
1. Directory Updated_Dataset that contains the data set for decision tree.
2. Shell script 'run.sh' used to run the program.

To execute the program, execute the run.sh script. 
bash run.sh